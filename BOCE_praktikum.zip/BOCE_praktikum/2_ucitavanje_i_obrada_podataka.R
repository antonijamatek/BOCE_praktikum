source("C:/Korisnici/Vaše ime/BOCE_praktimum/paketi_ucitavanje.R") #prilagodite za Vaš direktorij

Sys.setlocale("LC_TIME", "C") 

#funkcija za provjeriti direktorij
getwd()

#**UČITAVANJE PODATAKA*
#*koristimo paket readr (:: - pozivamo funkciju). Učitavamo podatke pomoću funkcije read_delim()

#0 metara, minutni interval
l0 <- readr::read_delim("Zrmanja_3004-0205_0m_1min_GMT+2.csv", delim = ",", show_col_types = FALSE) 
#8 metara, minutni interval
l8 <- readr::read_delim("Zrmanja_3004-0205_8m_1min_GMT+2.csv", delim = ",", show_col_types = FALSE)
#8 metara, 5-minutni interval
l8m <- readr::read_delim("Zrmanja_3004-0305_8m_5min_GMT+2.csv", delim = ",", show_col_types = FALSE)

#**UREĐIVANJE PODATAKA**

#POSTAVLJANJE PODATKOVNOG OKVIRA U "TIBBLE" FORMAT
l0 <- as_tibble(l0)
l8 <- as_tibble(l8)
l8m <- as_tibble(l8m)

#PRIKAZ PODATKOVNIH OKVIRA U KONZOLI
l0
l8
l8m

#Primjetite da su temperatura i svjetlost u "double" formatu, što znači da su numerički vektori.
#Datum i vrijeme (Timestamp) su tekstualni vektori, i trebamo ih pretvoriti u format za datum i vrijeme 
#<dttm>

#Funkcija prevodi vrijednosti u 24-satni format (izbacuje AM/PM), postavlja ih u format %Y-%m-%d %H:%M:%S
timestamp_format <- function(x) {
  timestamp <- mdy_hms(x)
  formatted_timestamp <- format(timestamp, "%Y-%m-%d %H:%M:%S")
  return(formatted_timestamp)
  }

#Primjena funkcije timestamp_format() na stupac sa datumom i vremenom:
l0$`Timestamp [GMT+02:00]` <- sapply(l0$`Timestamp [GMT+02:00]`, timestamp_format)

#Postavljanje u format <dttm>  primjenom funkcije POSIXct(): 
l0$`Timestamp [GMT+02:00]` <- as.POSIXct(l0$`Timestamp [GMT+02:00]`)

#Promjena vremenske zone iz GMT+02:00 u UTC+01:00 primjenom funkcije with_tz():
l0$`Timestamp [GMT+02:00]` <- with_tz(l0$`Timestamp [GMT+02:00]`, tzone = "Europe/London")

#Promjena imena stupca
colnames(l0)[2] <- "Timestamp [UTC+1]"

#Provjeri format
l0

#**VIZUALIZACIJA PODATAKA*
#*
#plotly paket za interaktivnu vizualizaciju podataka (drugi paket koji se može koristiti je ggplot2)
plot_ly(data = l0, 
        x = ~`Timestamp [UTC+1]`, 
        y = ~`Intensity [Lux]`,  
        type = 'scatter', 
        mode = 'lines') %>% 
  
  layout(xaxis = list(title = "Date in 2024 (UTC+1)"), 
         yaxis = list(title = "Light intensity (Lux)",
                      tickformat = ".1e"),
         title = "Surface - raw data 1 min interval")


#**1. ZADATAK Ponovi postupak za l8 i l8m*

#**2. ZADATAK Promotri podatke. Kako izgleda vremenski niz? Da li je potrebna dodatna obrada podataka?*


#Vremenski niz treba očistiti od ekstremnih vrijednosti koje možda nisu posljedica stvarnih mjerenja, već greške senzora

#Uportreba paketa dplyr za primjenu funkcija pipeline %>% i filter()

#**0 meters**
n_l0 <- l0 %>% filter(`Intensity [Lux]` < 20000) 

plot_ly(data = n_l0, 
        x = ~`Timestamp [UTC+1]`, 
        y = ~`Intensity [Lux]`,  
        type = 'scatter', 
        mode = 'lines') %>% 
  
  layout(xaxis = list(title = "Date in 2024 (UTC+1)"), 
         yaxis = list(title = "Light intensity (Lux)",
                      tickformat = ".1e"),
         title = "Surface - 1 min interval without extremes")


#**3. ZADATAK Na temelju originalnih vremenskih nizova na dubini od 8 m, odredi i vizualiziraj podskup podataka bez ekstremnih vrijednosti** 


#**8 meters: 1 minute interval**
n_l8 <- l8 %>% filter(`Intensity [Lux]` < x) #zamjeni x sa vrijednosti

plot_ly(data = n_l8, 
        x = ~`Timestamp [UTC+1]`, 
        y = ~`Intensity [Lux]`,  
        type = 'scatter', 
        mode = 'lines') %>% 
  
  layout(xaxis = list(title = "Date in 2024 (UTC+1)"), 
         yaxis = list(title = "Light intensity (Lux)",
                      tickformat = ".1e"),
         title = "8 m - 1 min interval without extremes")

#**8 meters: 5 minute interval**
n_l8m <- l8m %>% filter(`Intensity [Lux]` < x)  #zamjeni x sa vrijednosti

plot_ly(data = n_l8m, 
        x = ~`Timestamp [UTC+1]`, 
        y = ~`Intensity [Lux]`,  
        type = 'scatter', 
        mode = 'lines') %>% 
  
  layout(xaxis = list(title = "Date in 2024 (UTC+1)"), 
         yaxis = list(title = "Light intensity (Lux)",
                      tickformat = ".1e"),
         title = "8 m -5 min interval without extremes")

#**Zadatak 4. Usporedi 5-minutni i minutni intervala intenziteta svjetlosti na 8m dubine.
plot_ly(data = n_l8m, 
        x = ~`Timestamp [UTC+1]`, 
        y = ~`Intensity [Lux]`,  
        type = 'scatter', 
        mode = 'lines',
        name = "raw 5 min time interval") %>% 
  
  layout(xaxis = list(title = "Date in 2024 (UTC+1)"), 
         yaxis = list(title = "Light intensity (Lux)",
                      tickformat = ".1e"),
         title = "8 m : 5 min interval data") %>%  
  
  add_lines(data = n_l8, #dodajemo minutni interval 
            x = ~ `Timestamp [UTC+1]`, 
            y = ~ `Intensity [Lux]`,  
            type = 'scatter', 
            mode = 'lines', 
            name = "filtered from 1 min time interval")


