source("C:/Korisnici/Vaše ime/BOCE_praktimum/paketi_ucitavanje.R") #prilagodite za Vaš direktorij

Sys.setlocale("LC_TIME", "C")

#**FILTRIRANJE NISKIH FREKVENCIJA IZ ORIGINALNOG VREMENSKOG NIZA - PRIMJENA SREDNJEG KLIZNJAKA**
  

#**1. Određivanje indeksa je bitno kako bismo mogli ispravno primjeniti srednji kliznjak*

#*Datum i vrijeme definiramo kao naš indeks pomoću funkcije zoo()
ts_l0 <- zoo(n_l0$`Intensity [Lux]`, order.by = n_l0$`Timestamp [UTC+1]`)
ts_l8 <- zoo(n_l8$`Intensity [Lux]`, order.by = n_l8$`Timestamp [UTC+1]`)
ts_l8m <- zoo(n_l8m$`Intensity [Lux]`, order.by = n_l8m$`Timestamp [UTC+1]`)


#**2. Određivanje okvira za provođenje srednjeg kliznjaka*

#*1 min to 
#*30 min = 30, 
#*1 h = 60, 
#*3 h = 180, 
#*6 h = 360

 
#*5 min to 
#*30 min = 6, 
#*1 h = 12,
#*3 h = 36, 
#*6 h = 72

#**3. Primjena srednjeg kliznjaka na vremenskom nizu na 0 m upotrebom funckije rollapply()**
#**30 min*
l0_0.5h <- rollapply(ts_l0, 
                 width = 30, 
                 FUN = mean, 
                 align = "center", 
                 fill = NA) 

#Agregacija indeksa kako bi na x osi dobili polusatne vrijednosti
time <- index(ts_l0)
start_time <- min(time)
end_time <- max(time)
x <- seq.POSIXt(from = start_time, to = end_time, by = "30 min")
l0_0.5h <- aggregate(l0_0.5h, as.POSIXct(cut(time, breaks = x)), FUN = mean)


#**1 sat*
l0_h <- rollapply(ts_l0, 
                 width = 60, 
                 FUN = mean, 
                 align = "center", 
                 fill = NA)
#Agregacija indeksa kako bi na x osi dobili satne vrijednostI
x <- seq.POSIXt(from = start_time, to = end_time, by = "hour")
l0_h <- aggregate(l0h, as.POSIXct(cut(time, breaks = x)), FUN = mean)


#**3 sata*
l0_3h <- rollapply(ts_l0, 
                 width = 180, 
                 FUN = mean, 
                 align = "center", 
                 fill = NA)  
#Agregacija indeksa kako bi na x osi dobili trosatne vrijednosti
x <- seq.POSIXt(from = start_time, to = end_time, by = "3 hours")
l0_3h <- aggregate(l0_3h, as.POSIXct(cut(time, breaks = x)), FUN = mean)


#**6 sati*
l0_6h <- rollapply(ts_l0, 
                   width = 360, 
                   FUN = mean, 
                   align = "center", 
                   fill = NA)  
#Agregacija indeksa kako bi na x osi dobili šestosatne vrijednosti
x <- seq.POSIXt(from = start_time, to = end_time, by = "6 hours")
l0_6h <- aggregate(l0_6h, as.POSIXct(cut(time, breaks = x)), FUN = mean)

#**4. Podatkovni okvir odredimo kao "tibble" kako bi ga mogli vizualizirati upotrebom plotly()*
l0_0.5h <- tidy(l0_0.5h)
colnames(l0_0.5h)[1] <- "Timestamp [UTC+1]"
colnames(l0_0.5h)[2] <- "Intensity [Lux]"

l0_h <- tidy(l0_h) 
colnames(l0_h)[1] <- "Timestamp [UTC+1]"
colnames(l0_h)[2] <- "Intensity [Lux]"

l0_3h <- tidy(l0_3h) 
colnames(l0_3h)[1] <- "Timestamp [UTC+1]"
colnames(l0_3h)[2] <- "Intensity [Lux]"

l0_6h <- tidy(l0_6h) 
colnames(l0_6h)[1] <- "Timestamp [UTC+1]"
colnames(l0_6h)[2] <- "Intensity [Lux]"

#**5. VIZUALIZACIJA NIZOVA**

plot_ly(data = n_l0, 
        x = ~`Timestamp [UTC+1]`, 
        y = ~`Intensity [Lux]`,  
        type = 'scatter', 
        mode = 'lines',
        line = list(color = 'lightgray', width = 2, dash = 'solid'), #uređivanje linije
        name = "0 m = 5 min") %>%
  
  layout(xaxis = list(title = "Date in 2024 (UTC+1)"), 
         yaxis = list(title = "Light intensity (Lux)",
                      tickformat = ".1e"),
         title = "Filtriranje vremenskog niza" ) %>%
  
  add_lines(data = l0_0.5h,
            x = ~ `Timestamp [UTC+1]`, 
            y = ~ `Intensity [Lux]`,  
            type = 'scatter', 
            mode = 'lines', 
            line = list(color = 'red', width = 2, dash = 'solid'),
            name = "0 m = 30 min") %>%
  
  add_lines(data = l0_h,
            x = ~ `Timestamp [UTC+1]`, 
            y = ~ `Intensity [Lux]`,  
            type = 'scatter', 
            mode = 'lines', 
            line = list(color = 'blue', width = 2, dash = 'solid'),
            name = "0 m = 1 h") %>%
  
  add_lines(data = l0_3h,
            x = ~ `Timestamp [UTC+1]`, 
            y = ~ `Intensity [Lux]`,  
            type = 'scatter', 
            mode = 'lines', 
            line = list(color = 'green', width = 2, dash = 'solid'),
            name = "0 m = 3 h") %>%
  
  add_lines(data = l0_6h,
            x = ~ `Timestamp [UTC+1]`, 
            y = ~ `Intensity [Lux]`,  
            type = 'scatter', 
            mode = 'lines', 
            line = list(color = 'orange', width = 2, dash = 'solid'),
            name = " 0 m =6 h")
  





#**4. ZADATAK Ponovi postupak filtriranja vremenskog niza za minutni ILI petominutni vremenski niz na 8 m.**
#**a) 30 min*
#**a) 1 sat**
#**b) 3 sati**
#**c) 6 sati**
#**d) Postavi podatkovne okvire u "tibble" format**




#**5. ZADATAK Napravi svoju vizualizaciju filtriranih vremenskih nizova na 8 metara**
#**Sve atribute označene sa "#" možeš sam/-a odrediti, uredi krivulje, nazive krivulja, naziv prikaza...*
#**P.S U kodu je namjerno dodan jedan "bug" - probaj otkriti što nedostaje :)**
        
plotly(data = #x, 
        x = ~`Timestamp [UTC+1]`, 
        y = ~`Intensity [Lux]`,  
        type = 'scatter', 
        mode = 'lines',
        line = list(color = '#color', 
                    width = #broj 1 do 10, 
                    dash = '#solid or dash'),
        name = "#naziv linije") %>% 
  
  layout(xaxis = list(title = "Date in 2024 (UTC+1)"), 
         yaxis = list(title = "Light intensity (Lux)", tickformat = ".1e"),
         title = "#naziv cjelog prikaza") %>% 
  
  add_lines(data = #x,
            x = ~ `Timestamp [UTC+1]`, 
            y = ~ `Intensity [Lux]`,  
            type = 'scatter', 
            mode = 'lines', 
            line = list(color = '#color', 
                        width = #broj 1 do 10, 
                         dash = '#solid or dash'),
            name = "#naziv linije") %>%
  
  add_lines(data = #x,
            x = ~ `Timestamp [UTC+1]`, 
            y = ~ `Intensity [Lux]`,  
            type = 'scatter', 
            mode = 'lines',
            line = list(color = '#color', 
                        width = #broj 1 do 10, 
                        dash = '#solid or dash'),
            name = "#naziv linije") %>%
  
  add_lines(data = #x,
            x = ~ `Timestamp [UTC+1]`, 
            y = ~ `Intensity [Lux]`,  
            type = 'scatter', 
            mode = 'lines', 
            line = list(color = '#color', 
                        width = #broj 1 do 10, 
                        dash = '#solid or dash'),
            name = "#naziv linije")

  add_lines(data = #x,
            x = ~ `Timestamp [UTC+1]`, 
            y = ~ `Intensity [Lux]`,  
            type = 'scatter', 
            mode = 'lines', 
            line = list(color = '#color', 
                        width = #broj 1 do 10, 
                        dash = '#solid or dash'),
            name = "#naziv linije")
